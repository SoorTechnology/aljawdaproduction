
{
    "name": "Account General Ledger Report",
    "version": "13.0.1",
    "category": "Account",
    "author": "Account Account",
    "summary": "Account",
    "website": "Account",
    "depends": ["account_reports"],
    "data": [
            "views/report_financial.xml"
            ],
    "installable": True,
    "auto_install": False,
}
